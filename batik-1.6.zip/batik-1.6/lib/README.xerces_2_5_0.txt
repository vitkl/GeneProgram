The xerces_2_5_0.jar file comes from the Apache Xerces project:

http://xml.apache.org/dist/xerces-j/
